using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public List<Card> deck = new List<Card>();
    public List<Card> discardPile = new List<Card>();

    public Transform[] handSlots;
    public bool[] availableHandSlots;

    public Transform[] fieldSlots;
    public bool[] availableFieldSlots;
    
    
    public void DrawCard(){
        if(deck.Count >= 1){
            Card randCard = deck[Random.Range(0, deck.Count)];

            for(int i = 0; i < availableHandSlots.Length; i++){
                if(availableHandSlots[i] == true){
                    randCard.gameObject.SetActive(true);
                    randCard.handIndex = i;
                    randCard.transform.position = new Vector3(handSlots[i].position.x, handSlots[i].position.y, handSlots[i].position.z - 1);
                    randCard.isPlayed = false;
                    availableHandSlots[i] = false;
                    deck.Remove(randCard);
                    return;
                }
            }
        }
    }

    public void PlayCard(Card card){

        for(int i = 0; i < availableFieldSlots.Length; i++){
            if(availableFieldSlots[i] == true){
                card.transform.position = new Vector3(fieldSlots[i].position.x, fieldSlots[i].position.y, fieldSlots[i].position.z - 1);
                card.isPlayed = true;
                availableHandSlots[card.handIndex] = true;
                card.handIndex = -1;
                availableFieldSlots[i] = false;
                return;
            }
        }
    }
}
