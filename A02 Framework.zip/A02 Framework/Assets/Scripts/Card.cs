using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Card : MonoBehaviour
{
    public bool isPlayed;
    public int handIndex;
    private GameManager gm;

    private void Start(){
        gm = FindObjectOfType<GameManager>();
    }

    private void OnMouseDown(){
        if(isPlayed == false){
            gm.PlayCard(this);
        }else{
            Discard();
        }
    }

    void Discard(){
        gm.discardPile.Add(this);
        gameObject.SetActive(false);
    }
}
